import kinetics
import matplotlib.pyplot as plt
from scipy.stats import norm

class vPts1_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kmPts1','EIIAtotal','kPts1']
		self.reaction_substrate_names = ['ATP','pH','PEP','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['PEP']
		self.products = ['PYR','EIIAP']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PEP = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kmPts1 = parameters[0]
		EIIAtotal = parameters[1]
		kPts1 = parameters[2]



		EIIA=EIIAtotal-EIIAP
		rate=kPts1*PEP*EIIA-kmPts1*PYR*EIIAP

		return rate

class vPts4_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KPts_GLC','KPts_EIIA','vPts4_max']
		self.reaction_substrate_names = ['GLCex','EIIAP']
		self.substrates = ['EIIAP']
		self.products = ['G6P']


	def calculate_rate(self, substrates, parameters):
		GLCex = substrates[0]
		EIIAP = substrates[1]


		KPts_GLC = parameters[0]
		KPts_EIIA = parameters[1]
		vPts4_max = parameters[2]



		rate=vPts4_max*EIIAP*GLCex/((KPts_EIIA+EIIAP)*(KPts_GLC+GLCex))

		return rate

class vPts4_medium_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KPts_GLC','KPts_EIIA','rho','vPts4_max']
		self.reaction_substrate_names = ['GLCex','EIIAP','X']
		self.substrates = ['GLCex']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		GLCex = substrates[0]
		EIIAP = substrates[1]
		X = substrates[2]


		KPts_GLC = parameters[0]
		KPts_EIIA = parameters[1]
		rho = parameters[2]
		vPts4_max = parameters[3]



		vPts4=vPts4_max*EIIAP*GLCex/((KPts_EIIA+EIIAP)*(KPts_GLC+GLCex))
		rate=vPts4*X/rho

		return rate

class vNonpts_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KNonpts_S','KNonpts_I','EIIAtotal','vNonpts_max']
		self.reaction_substrate_names = ['ATP','pH','GLCex','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['GLC']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		GLCex = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		KNonpts_S = parameters[0]
		KNonpts_I = parameters[1]
		EIIAtotal = parameters[2]
		vNonpts_max = parameters[3]



		EIIA=EIIAtotal-EIIAP
		rate=vNonpts_max*GLCex/(KNonpts_S+(1+EIIA/KNonpts_I)*GLCex)

		return rate

class vNonpts_medium_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['rho','KNonpts_S','KNonpts_I','EIIAtotal','vNonpts_max']
		self.reaction_substrate_names = ['ATP','pH','GLCex','PYR','EIIAP','FBP','cAMP','X']
		self.substrates = ['GLCex']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		GLCex = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]
		X = substrates[7]


		rho = parameters[0]
		KNonpts_S = parameters[1]
		KNonpts_I = parameters[2]
		EIIAtotal = parameters[3]
		vNonpts_max = parameters[4]



		EIIA=EIIAtotal-EIIAP
		vNonpts=vNonpts_max*GLCex/(KNonpts_S+(1+EIIA/KNonpts_I)*GLCex)
		rate=vNonpts*X/rho

		return rate

class vE_Glk_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KGlk_G6P_i','KGlk_GLC_m','kGlk_cat','KGlk_ATP_m']
		self.reaction_substrate_names = ['GLC','ATP','G6P','Glk']
		self.substrates = ['GLC','ATP']
		self.products = ['G6P','ADP']


	def calculate_rate(self, substrates, parameters):
		GLC = substrates[0]
		ATP = substrates[1]
		G6P = substrates[2]
		Glk = substrates[3]


		KGlk_G6P_i = parameters[0]
		KGlk_GLC_m = parameters[1]
		kGlk_cat = parameters[2]
		KGlk_ATP_m = parameters[3]



		rate=Glk*kGlk_cat*(GLC/KGlk_GLC_m)*(ATP/(KGlk_ATP_m*(1+G6P/KGlk_G6P_i)))/(1+GLC/KGlk_GLC_m+ATP/(KGlk_ATP_m*(1+G6P/KGlk_G6P_i))+GLC*ATP/(KGlk_GLC_m*KGlk_ATP_m*(1+G6P/KGlk_G6P_i))+G6P/KGlk_G6P_i)

		return rate

class vE_Pgi_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KPgi_F6P_6pginh','vPgi_max','KPgi_G6P','KPgi_F6P','KPgi_G6P_6pginh','KPgi_eq']
		self.reaction_substrate_names = ['G6P','sixPG','F6P']
		self.substrates = ['G6P']
		self.products = ['F6P']


	def calculate_rate(self, substrates, parameters):
		G6P = substrates[0]
		sixPG = substrates[1]
		F6P = substrates[2]


		KPgi_F6P_6pginh = parameters[0]
		vPgi_max = parameters[1]
		KPgi_G6P = parameters[2]
		KPgi_F6P = parameters[3]
		KPgi_G6P_6pginh = parameters[4]
		KPgi_eq = parameters[5]



		rate=vPgi_max*(G6P-F6P/KPgi_eq)/(KPgi_G6P*(1+F6P/(KPgi_F6P*(1+sixPG/KPgi_F6P_6pginh))+sixPG/KPgi_G6P_6pginh)+G6P)

		return rate

class vE_Pfk_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['nPfk','LPfk','kPfk_cat','KPfk_ADP_c','KPfk_PEP','KPfk_AMP_b','KPfk_AMP_a','KPfk_ATP_s','KPfk_F6P_s','KPfk_ADP_b','KPfk_ADP_a']
		self.reaction_substrate_names = ['ATP','AMP','ADP','PEP','Pfk','F6P']
		self.substrates = ['F6P','ATP']
		self.products = ['FBP','ADP']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		AMP = substrates[1]
		ADP = substrates[2]
		PEP = substrates[3]
		Pfk = substrates[4]
		F6P = substrates[5]


		nPfk = parameters[0]
		LPfk = parameters[1]
		kPfk_cat = parameters[2]
		KPfk_ADP_c = parameters[3]
		KPfk_PEP = parameters[4]
		KPfk_AMP_b = parameters[5]
		KPfk_AMP_a = parameters[6]
		KPfk_ATP_s = parameters[7]
		KPfk_F6P_s = parameters[8]
		KPfk_ADP_b = parameters[9]
		KPfk_ADP_a = parameters[10]


		A=1+PEP/KPfk_PEP+ADP/KPfk_ADP_b+AMP/KPfk_AMP_b
		B=1+ADP/KPfk_ADP_a+AMP/KPfk_AMP_a

		rate=Pfk*kPfk_cat*ATP*F6P/((ATP+KPfk_ATP_s*(1+ADP/KPfk_ADP_c))*(F6P+KPfk_F6P_s*A/B)*(1+LPfk/pow(1+F6P*B/(KPfk_F6P_s*A),nPfk)))

		return rate

class vE_Fbp_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KFbp_PEP','kFbp_cat','KFbp_FBP','nFbp','LFbp']
		self.reaction_substrate_names = ['Fbp','PEP','FBP']
		self.substrates = ['FBP']
		self.products = ['F6P']


	def calculate_rate(self, substrates, parameters):
		Fbp = substrates[0]
		PEP = substrates[1]
		FBP = substrates[2]


		KFbp_PEP = parameters[0]
		kFbp_cat = parameters[1]
		KFbp_FBP = parameters[2]
		nFbp = parameters[3]
		LFbp = parameters[4]



		rate=Fbp*kFbp_cat*FBP/KFbp_FBP*pow(1+FBP/KFbp_FBP,nFbp-1)/(pow(1+FBP/KFbp_FBP,nFbp)+LFbp/pow(1+PEP/KFbp_PEP,nFbp))

		return rate

class vE_Fba_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['VFba_blf','KFba_DHAP','KFba_GAP','KFba_FBP','kFba_cat','KFba_GAP_inh','KFba_eq']
		self.reaction_substrate_names = ['Fba','GAP','FBP']
		self.substrates = ['FBP']
		self.products = ['GAP','DAP']


	def calculate_rate(self, substrates, parameters):
		Fba = substrates[0]
		GAP = substrates[1]
		FBP = substrates[2]


		VFba_blf = parameters[0]
		KFba_DHAP = parameters[1]
		KFba_GAP = parameters[2]
		KFba_FBP = parameters[3]
		kFba_cat = parameters[4]
		KFba_GAP_inh = parameters[5]
		KFba_eq = parameters[6]



		rate=Fba*kFba_cat*(FBP-pow(GAP,2)/KFba_eq)/(KFba_FBP+FBP+KFba_GAP*GAP/(KFba_eq*VFba_blf)+KFba_DHAP*GAP/(KFba_eq*VFba_blf)+FBP*GAP/KFba_GAP_inh+pow(GAP,2)/(KFba_eq*VFba_blf))

		return rate

class vE_Eno_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KEno_eq','vEno_max','KEno_Pep','KEno_Pga2']
		self.reaction_substrate_names = ['PEP','PGA2']
		self.substrates = ['PGA2']
		self.products = ['PEP']


	def calculate_rate(self, substrates, parameters):
		PEP = substrates[0]
		PGA2 = substrates[1]


		KEno_eq = parameters[0]
		vEno_max = parameters[1]
		KEno_Pep = parameters[2]
		KEno_Pga2 = parameters[3]



		rate=((vEno_max*(PGA2-PEP/KEno_eq))/KEno_Pga2)/(1+(PGA2/KEno_Pga2)+(PEP/KEno_Pep))

		return rate

class vE_Tpi_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['K_TPI_KmGAP','K_TPI_Keq','K_TPI_KmDAP','v_TPI_Vmax']
		self.reaction_substrate_names = ['DAP','GAP']
		self.substrates = ['DAP']
		self.products = ['GAP']


	def calculate_rate(self, substrates, parameters):
		DAP = substrates[0]
		GAP = substrates[1]


		K_TPI_KmGAP = parameters[0]
		K_TPI_Keq = parameters[1]
		K_TPI_KmDAP = parameters[2]
		v_TPI_Vmax = parameters[3]



		rate=v_TPI_Vmax*(DAP-GAP/K_TPI_Keq)/K_TPI_KmDAP/(1+DAP/K_TPI_KmDAP+GAP/K_TPI_KmGAP)

		return rate

class vE_Pgk_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['K_PGK_KmPGA3','K_PGK_KmADPMg','v_PGK_Vmax','K_PGK_Keq','K_PGK_KmATPMg','K_PGK_KmBPG']
		self.reaction_substrate_names = ['PGA3','BPG','ADP','ATP']
		self.substrates = ['BPG','ADP']
		self.products = ['PGA3','ATP']


	def calculate_rate(self, substrates, parameters):
		PGA3 = substrates[0]
		BPG = substrates[1]
		ADP = substrates[2]
		ATP = substrates[3]


		K_PGK_KmPGA3 = parameters[0]
		K_PGK_KmADPMg = parameters[1]
		v_PGK_Vmax = parameters[2]
		K_PGK_Keq = parameters[3]
		K_PGK_KmATPMg = parameters[4]
		K_PGK_KmBPG = parameters[5]



		rate=v_PGK_Vmax*(ADP*BPG-ATP*PGA3/K_PGK_Keq)/(K_PGK_KmADPMg*K_PGK_KmBPG)/(1+ADP/K_PGK_KmADPMg+BPG/K_PGK_KmBPG+ADP/K_PGK_KmADPMg*BPG/K_PGK_KmBPG+ATP/K_PGK_KmATPMg+PGA3/K_PGK_KmPGA3+ATP/K_PGK_KmATPMg*PGA3/K_PGK_KmPGA3)

		return rate

class vE_Gpm_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['K_GPM_KmPGA3','v_GPM_Vmax','K_GPM_Keq','K_GPM_KmPGA2']
		self.reaction_substrate_names = ['PGA3','PGA2']
		self.substrates = ['PGA3']
		self.products = ['PGA2']


	def calculate_rate(self, substrates, parameters):
		PGA3 = substrates[0]
		PGA2 = substrates[1]


		K_GPM_KmPGA3 = parameters[0]
		v_GPM_Vmax = parameters[1]
		K_GPM_Keq = parameters[2]
		K_GPM_KmPGA2 = parameters[3]



		rate=v_GPM_Vmax*(PGA3-PGA2/K_GPM_Keq)/K_GPM_KmPGA3/(1+PGA3/K_GPM_KmPGA3+PGA2/K_GPM_KmPGA2)

		return rate

class vE_Gdh_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['K_GDH_Keq','K_GDH_KmNADH','K_GDH_KmBPG','K_GDH_KmP','v_GDH_Vmax','K_GDH_KmGAP','K_GDH_KmNAD']
		self.reaction_substrate_names = ['NAD','BPG','P','NADH','GAP']
		self.substrates = ['GAP']
		self.products = ['BPG']


	def calculate_rate(self, substrates, parameters):
		NAD = substrates[0]
		BPG = substrates[1]
		P = substrates[2]
		NADH = substrates[3]
		GAP = substrates[4]


		K_GDH_Keq = parameters[0]
		K_GDH_KmNADH = parameters[1]
		K_GDH_KmBPG = parameters[2]
		K_GDH_KmP = parameters[3]
		v_GDH_Vmax = parameters[4]
		K_GDH_KmGAP = parameters[5]
		K_GDH_KmNAD = parameters[6]



		rate=v_GDH_Vmax*(P*GAP*NAD-BPG*NADH/K_GDH_Keq)/(K_GDH_KmP*K_GDH_KmGAP*K_GDH_KmNAD)/((1+P/K_GDH_KmP)*(1+GAP/K_GDH_KmGAP)*(1+NAD/K_GDH_KmNAD)+(1+BPG/K_GDH_KmBPG)*(1+NADH/K_GDH_KmNADH)-1)

		return rate

class vE_Pyk_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['nPyk','LPyk','KPyk_AMP','KPyk_FBP','KPyk_PEP','KPyk_ADP','KPyk_ATP','kPyk_cat']
		self.reaction_substrate_names = ['ATP','AMP','ADP','PEP','Pyk','FBP']
		self.substrates = ['PEP','ADP']
		self.products = ['PYR','ATP']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		AMP = substrates[1]
		ADP = substrates[2]
		PEP = substrates[3]
		Pyk = substrates[4]
		FBP = substrates[5]


		nPyk = parameters[0]
		LPyk = parameters[1]
		KPyk_AMP = parameters[2]
		KPyk_FBP = parameters[3]
		KPyk_PEP = parameters[4]
		KPyk_ADP = parameters[5]
		KPyk_ATP = parameters[6]
		kPyk_cat = parameters[7]



		rate=Pyk*kPyk_cat*PEP*pow(PEP/KPyk_PEP+1,nPyk-1)*ADP/(KPyk_PEP*(LPyk*pow((1+ATP/KPyk_ATP)/(FBP/KPyk_FBP+AMP/KPyk_AMP+1),nPyk)+pow(PEP/KPyk_PEP+1,nPyk))*(ADP+KPyk_ADP))

		return rate

class vE_Pps_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KPps_PEP','LPps','KPps_PYR','kPps_cat','nPps']
		self.reaction_substrate_names = ['Pps','PYR','PEP']
		self.substrates = ['PYR','ATP']
		self.products = ['PEP']


	def calculate_rate(self, substrates, parameters):
		Pps = substrates[0]
		PYR = substrates[1]
		PEP = substrates[2]


		KPps_PEP = parameters[0]
		LPps = parameters[1]
		KPps_PYR = parameters[2]
		kPps_cat = parameters[3]
		nPps = parameters[4]



		rate=Pps*kPps_cat*PYR/KPps_PYR*pow(1+PYR/KPps_PYR,nPps-1)/(pow(1+PYR/KPps_PYR,nPps)+LPps*pow(1+PEP/KPps_PEP,nPps))

		return rate

class vE_Pdh_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KPdh_i','kPdh_cat','KPdh_PYR_m','KPdh_NAD_m','KPdh_CoA_m','KPdh_NADH_m','KPdh_AcCoA_m']
		self.reaction_substrate_names = ['NAD','AcCoA','PYR','Pdh','NADH','CoA']
		self.substrates = ['PYR']
		self.products = ['AcCoA']


	def calculate_rate(self, substrates, parameters):
		NAD = substrates[0]
		AcCoA = substrates[1]
		PYR = substrates[2]
		Pdh = substrates[3]
		NADH = substrates[4]
		CoA = substrates[5]


		KPdh_i = parameters[0]
		kPdh_cat = parameters[1]
		KPdh_PYR_m = parameters[2]
		KPdh_NAD_m = parameters[3]
		KPdh_CoA_m = parameters[4]
		KPdh_NADH_m = parameters[5]
		KPdh_AcCoA_m = parameters[6]



		rate=Pdh*kPdh_cat*(1/(1+KPdh_i*NADH/NAD))*(PYR/KPdh_PYR_m)*(NAD/KPdh_NAD_m)*(CoA/KPdh_CoA_m)/((1+PYR/KPdh_PYR_m)*(1+NAD/KPdh_NAD_m+NADH/KPdh_NADH_m)*(1+CoA/KPdh_CoA_m+AcCoA/KPdh_AcCoA_m))

		return rate

class vE_Pta_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KPta_AcP_m','KPta_Pi_i','KPta_Pi_m','KPta_AcP_i','vPta_max','KPta_AcCoA_i','KPta_eq','KPta_CoA_i']
		self.reaction_substrate_names = ['Pi','AcCoA','AcP','CoA']
		self.substrates = ['AcCoA']
		self.products = ['AcP']


	def calculate_rate(self, substrates, parameters):
		Pi = substrates[0]
		AcCoA = substrates[1]
		AcP = substrates[2]
		CoA = substrates[3]


		KPta_AcP_m = parameters[0]
		KPta_Pi_i = parameters[1]
		KPta_Pi_m = parameters[2]
		KPta_AcP_i = parameters[3]
		vPta_max = parameters[4]
		KPta_AcCoA_i = parameters[5]
		KPta_eq = parameters[6]
		KPta_CoA_i = parameters[7]



		rate=vPta_max*(1/(KPta_AcCoA_i*KPta_Pi_m))*(AcCoA*Pi-AcP*CoA/KPta_eq)/(1+AcCoA/KPta_AcCoA_i+Pi/KPta_Pi_i+AcP/KPta_AcP_i+CoA/KPta_CoA_i+AcCoA*Pi/(KPta_AcCoA_i*KPta_Pi_m)+AcP*CoA/(KPta_AcP_m*KPta_CoA_i))

		return rate

class vE_Ack_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KAck_AcP_m','KAck_ADP_m','KAck_eq','vAck_max','KAck_ACE_m','KAck_ATP_m']
		self.reaction_substrate_names = ['ATP','ADP','AcP','ACEex']
		self.substrates = ['AcP','ADP']
		self.products = ['ATP']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		ADP = substrates[1]
		AcP = substrates[2]
		ACEex = substrates[3]


		KAck_AcP_m = parameters[0]
		KAck_ADP_m = parameters[1]
		KAck_eq = parameters[2]
		vAck_max = parameters[3]
		KAck_ACE_m = parameters[4]
		KAck_ATP_m = parameters[5]



		rate=vAck_max*(1/(KAck_ADP_m*KAck_AcP_m))*(AcP*ADP-ACEex*ATP/KAck_eq)/((1+AcP/KAck_AcP_m+ACEex/KAck_ACE_m)*(1+ADP/KAck_ADP_m+ATP/KAck_ATP_m))

		return rate

class vE_Ack_medium_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KAck_AcP_m','KAck_ADP_m','KAck_eq','rho','vAck_max','KAck_ACE_m','KAck_ATP_m']
		self.reaction_substrate_names = ['ATP','AcP','ADP','ACEex','X']
		self.substrates = []
		self.products = ['ACEex']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		AcP = substrates[1]
		ADP = substrates[2]
		ACEex = substrates[3]
		X = substrates[4]


		KAck_AcP_m = parameters[0]
		KAck_ADP_m = parameters[1]
		KAck_eq = parameters[2]
		rho = parameters[3]
		vAck_max = parameters[4]
		KAck_ACE_m = parameters[5]
		KAck_ATP_m = parameters[6]



		vE_Ack=vAck_max*(1/(KAck_ADP_m*KAck_AcP_m))*(AcP*ADP-ACEex*ATP/KAck_eq)/((1+AcP/KAck_AcP_m+ACEex/KAck_ACE_m)*(1+ADP/KAck_ADP_m+ATP/KAck_ATP_m))
		rate=vE_Ack*X/rho

		return rate

class vE_Acs_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KAcs_ACE','kAcs_cat']
		self.reaction_substrate_names = ['ACEex','Acs']
		self.substrates = ['ATP']
		self.products = ['AcCoA']


	def calculate_rate(self, substrates, parameters):
		ACEex = substrates[0]
		Acs = substrates[1]


		KAcs_ACE = parameters[0]
		kAcs_cat = parameters[1]



		rate=Acs*kAcs_cat*ACEex/(ACEex+KAcs_ACE)

		return rate

class vE_Acs_medium_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KAcs_ACE','kAcs_cat','rho']
		self.reaction_substrate_names = ['ACEex','Acs','X']
		self.substrates = ['ACEex']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ACEex = substrates[0]
		Acs = substrates[1]
		X = substrates[2]


		KAcs_ACE = parameters[0]
		kAcs_cat = parameters[1]
		rho = parameters[2]



		vE_Acs=Acs*kAcs_cat*ACEex/(ACEex+KAcs_ACE)
		rate=vE_Acs*X/rho

		return rate

class vE_Cs_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kCs_cat','KCs_OAA','KCs_aKG','KCs_AcCoA','KCs_OAA_AcCoA']
		self.reaction_substrate_names = ['OAA','AcCoA','Cs','aKG']
		self.substrates = ['AcCoA','OAA']
		self.products = ['ICIT']


	def calculate_rate(self, substrates, parameters):
		OAA = substrates[0]
		AcCoA = substrates[1]
		Cs = substrates[2]
		aKG = substrates[3]


		kCs_cat = parameters[0]
		KCs_OAA = parameters[1]
		KCs_aKG = parameters[2]
		KCs_AcCoA = parameters[3]
		KCs_OAA_AcCoA = parameters[4]



		rate=Cs*kCs_cat*OAA*AcCoA/((1+aKG/KCs_aKG)*KCs_OAA_AcCoA*KCs_AcCoA+KCs_AcCoA*OAA+(1+aKG/KCs_aKG)*KCs_OAA*AcCoA+OAA*AcCoA)

		return rate

class vE_Icdh_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['nIcdh','kIcdh_cat','icdh_b','KIcdh_PEP','KIcdh_ICIT','LIcdh']
		self.reaction_substrate_names = ['PEP','Icdh','ICIT']
		self.substrates = ['ICIT']
		self.products = ['aKG']


	def calculate_rate(self, substrates, parameters):
		PEP = substrates[0]
		Icdh = substrates[1]
		ICIT = substrates[2]


		nIcdh = parameters[0]
		kIcdh_cat = parameters[1]
		icdh_b = parameters[2]
		KIcdh_PEP = parameters[3]
		KIcdh_ICIT = parameters[4]
		LIcdh = parameters[5]



		rate=(Icdh+icdh_b)*kIcdh_cat*ICIT/KIcdh_ICIT*pow(1+ICIT/KIcdh_ICIT,nIcdh-1)/(pow(1+ICIT/KIcdh_ICIT,nIcdh)+LIcdh*pow(1+PEP/KIcdh_PEP,nIcdh))

		return rate

class vE_akgdh_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['Kakgdh_NADH_I','Kakgdh_aKG_m','Kakgdh_CoA_m','Kakgdh_Z','Kakgdh_NAD_m','kakgdh_cat','Kakgdh_SUC_I','Kakgdh_aKG_I']
		self.reaction_substrate_names = ['NAD','aKG','akgdh','SUC','NADH','CoA']
		self.substrates = ['aKG','ADP']
		self.products = ['SUC','ATP']


	def calculate_rate(self, substrates, parameters):
		NAD = substrates[0]
		aKG = substrates[1]
		akgdh = substrates[2]
		SUC = substrates[3]
		NADH = substrates[4]
		CoA = substrates[5]


		Kakgdh_NADH_I = parameters[0]
		Kakgdh_aKG_m = parameters[1]
		Kakgdh_CoA_m = parameters[2]
		Kakgdh_Z = parameters[3]
		Kakgdh_NAD_m = parameters[4]
		kakgdh_cat = parameters[5]
		Kakgdh_SUC_I = parameters[6]
		Kakgdh_aKG_I = parameters[7]



		rate=akgdh*kakgdh_cat*aKG*CoA*NAD/(Kakgdh_NAD_m*aKG*CoA+Kakgdh_CoA_m*aKG*NAD+Kakgdh_aKG_m*CoA*NAD+aKG*CoA*NAD+Kakgdh_aKG_m*Kakgdh_Z*SUC*NADH/Kakgdh_SUC_I+Kakgdh_NAD_m*aKG*CoA*NADH/Kakgdh_NADH_I+Kakgdh_CoA_m*aKG*NAD*SUC/Kakgdh_SUC_I+Kakgdh_aKG_m*Kakgdh_Z*aKG*SUC*NADH/(Kakgdh_aKG_I*Kakgdh_SUC_I))

		return rate

class vE_Sdh_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kSdh1_cat','KSdh_eq','kSdh2_cat','KSdh_SUC_m']
		self.reaction_substrate_names = ['FUM','SUC','Sdh']
		self.substrates = ['SUC']
		self.products = ['FUM']


	def calculate_rate(self, substrates, parameters):
		FUM = substrates[0]
		SUC = substrates[1]
		Sdh = substrates[2]


		kSdh1_cat = parameters[0]
		KSdh_eq = parameters[1]
		kSdh2_cat = parameters[2]
		KSdh_SUC_m = parameters[3]


		vSdh1_max=Sdh*kSdh1_cat
		vSdh2_max=Sdh*kSdh2_cat

		rate=vSdh1_max*vSdh2_max*(SUC-FUM/KSdh_eq)/(KSdh_SUC_m*vSdh2_max+vSdh2_max*SUC+vSdh1_max*FUM/KSdh_eq)

		return rate

class vE_Fum_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kFum2_cat','KFum_FUM_m','kFum1_cat','KFum_eq']
		self.reaction_substrate_names = ['Fum','FUM','MAL']
		self.substrates = ['FUM']
		self.products = ['MAL']


	def calculate_rate(self, substrates, parameters):
		Fum = substrates[0]
		FUM = substrates[1]
		MAL = substrates[2]


		kFum2_cat = parameters[0]
		KFum_FUM_m = parameters[1]
		kFum1_cat = parameters[2]
		KFum_eq = parameters[3]


		vFum1_max=Fum*kFum1_cat
		vFum2_max=Fum*kFum2_cat

		rate=vFum1_max*vFum2_max*(FUM-MAL/KFum_eq)/(KFum_FUM_m*vFum2_max+vFum2_max*FUM+vFum1_max*MAL/KFum_eq)

		return rate

class vE_Mdh_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KMdh_OAA_II','KMdh_OAA_m','KMdh_MAL_I','KMdh_eq','KMdh_NAD_II','KMdh_NAD_I','kMdh1_cat','KMdh_MAL_m','KMdh_NADH_m','KMdh_OAA_I','KMdh_NAD_m','kMdh2_cat','KMdh_NADH_I']
		self.reaction_substrate_names = ['NAD','MAL','NADH','OAA','Mdh']
		self.substrates = ['MAL']
		self.products = ['OAA']


	def calculate_rate(self, substrates, parameters):
		NAD = substrates[0]
		MAL = substrates[1]
		NADH = substrates[2]
		OAA = substrates[3]
		Mdh = substrates[4]


		KMdh_OAA_II = parameters[0]
		KMdh_OAA_m = parameters[1]
		KMdh_MAL_I = parameters[2]
		KMdh_eq = parameters[3]
		KMdh_NAD_II = parameters[4]
		KMdh_NAD_I = parameters[5]
		kMdh1_cat = parameters[6]
		KMdh_MAL_m = parameters[7]
		KMdh_NADH_m = parameters[8]
		KMdh_OAA_I = parameters[9]
		KMdh_NAD_m = parameters[10]
		kMdh2_cat = parameters[11]
		KMdh_NADH_I = parameters[12]


		vMdh1_max=Mdh*kMdh1_cat
		vMdh2_max=Mdh*kMdh2_cat

		rate=vMdh1_max*vMdh2_max*(NAD*MAL-NADH*OAA/KMdh_eq)/(KMdh_NAD_I*KMdh_MAL_m*vMdh2_max+KMdh_MAL_m*vMdh2_max*NAD+KMdh_NAD_m*vMdh2_max*MAL+vMdh2_max*NAD*MAL+KMdh_OAA_m*vMdh1_max*NADH/KMdh_eq+KMdh_NADH_m*vMdh1_max*OAA/KMdh_eq+vMdh1_max*NADH*OAA/KMdh_eq+vMdh1_max*KMdh_OAA_m*NAD*NADH/(KMdh_eq*KMdh_NAD_I)+vMdh2_max*KMdh_NAD_m*MAL*OAA/KMdh_OAA_I+vMdh2_max*NAD*MAL*NADH/KMdh_NADH_I+vMdh1_max*MAL*NADH*OAA/(KMdh_eq*KMdh_MAL_I)+vMdh2_max*NAD*MAL*OAA/KMdh_OAA_II+vMdh1_max*NAD*NADH*OAA/(KMdh_NAD_II*KMdh_eq)+KMdh_NAD_I*vMdh2_max*NAD*MAL*NADH*OAA/(KMdh_NAD_II*KMdh_OAA_m*KMdh_NADH_I))

		return rate

class vE_MaeB_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KMaeB_MAL','KMaeB_cAMP','nMaeB','kMaeB_cat','KMaeB_AcCoA','LMaeB']
		self.reaction_substrate_names = ['MaeB','AcCoA','MAL','cAMP']
		self.substrates = ['MAL']
		self.products = ['PYR']


	def calculate_rate(self, substrates, parameters):
		MaeB = substrates[0]
		AcCoA = substrates[1]
		MAL = substrates[2]
		cAMP = substrates[3]


		KMaeB_MAL = parameters[0]
		KMaeB_cAMP = parameters[1]
		nMaeB = parameters[2]
		kMaeB_cat = parameters[3]
		KMaeB_AcCoA = parameters[4]
		LMaeB = parameters[5]



		rate=MaeB*kMaeB_cat*MAL/KMaeB_MAL*pow(1+MAL/KMaeB_MAL,nMaeB-1)/(pow(1+MAL/KMaeB_MAL,nMaeB)+LMaeB*pow(1+AcCoA/KMaeB_AcCoA+cAMP/KMaeB_cAMP,nMaeB))

		return rate

class vE_Pck_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KPck_PEP','KPck_OAA','KPck_ATP_I','KPck_OAA_I','KPck_ATP_i','KPck_ADP_i','kPck_cat','KPck_PEP_i']
		self.reaction_substrate_names = ['ATP','ADP','Pck','PEP','OAA']
		self.substrates = ['OAA','ATP']
		self.products = ['PEP','ADP']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		ADP = substrates[1]
		Pck = substrates[2]
		PEP = substrates[3]
		OAA = substrates[4]


		KPck_PEP = parameters[0]
		KPck_OAA = parameters[1]
		KPck_ATP_I = parameters[2]
		KPck_OAA_I = parameters[3]
		KPck_ATP_i = parameters[4]
		KPck_ADP_i = parameters[5]
		kPck_cat = parameters[6]
		KPck_PEP_i = parameters[7]



		rate=Pck*kPck_cat*OAA*ATP/ADP/(KPck_OAA*ATP/ADP+OAA*ATP/ADP+KPck_ATP_i*KPck_OAA/KPck_ADP_i+KPck_ATP_i*KPck_OAA/(KPck_PEP*KPck_ADP_i)*PEP+KPck_ATP_i*KPck_OAA/(KPck_PEP_i*KPck_ATP_I)*ATP/ADP*PEP+KPck_ATP_i*KPck_OAA/(KPck_ADP_i*KPck_OAA_I)*OAA)

		return rate

class vE_Ppc_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KPpc_PEP','KPpc_FBP','kPpc_cat','LPpc','nPpc']
		self.reaction_substrate_names = ['PEP','Ppc','FBP']
		self.substrates = ['PEP']
		self.products = ['OAA']


	def calculate_rate(self, substrates, parameters):
		PEP = substrates[0]
		Ppc = substrates[1]
		FBP = substrates[2]


		KPpc_PEP = parameters[0]
		KPpc_FBP = parameters[1]
		kPpc_cat = parameters[2]
		LPpc = parameters[3]
		nPpc = parameters[4]



		rate=Ppc*kPpc_cat*PEP/KPpc_PEP*pow(1+PEP/KPpc_PEP,nPpc-1)/(pow(1+PEP/KPpc_PEP,nPpc)+LPpc/pow(1+FBP/KPpc_FBP,nPpc))

		return rate

class vE_Icl_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kIcl_cat','KIcl_ICIT','LIcl','KIcl_3PG','KIcl_PEP','nIcl','KIcl_aKG']
		self.reaction_substrate_names = ['aKG','Icl','PEP','ICIT','GAP']
		self.substrates = ['ICIT']
		self.products = ['SUC','GOX']


	def calculate_rate(self, substrates, parameters):
		aKG = substrates[0]
		Icl = substrates[1]
		PEP = substrates[2]
		ICIT = substrates[3]
		GAP = substrates[4]


		kIcl_cat = parameters[0]
		KIcl_ICIT = parameters[1]
		LIcl = parameters[2]
		KIcl_3PG = parameters[3]
		KIcl_PEP = parameters[4]
		nIcl = parameters[5]
		KIcl_aKG = parameters[6]



		rate=Icl*kIcl_cat*ICIT/KIcl_ICIT*pow(1+ICIT/KIcl_ICIT,nIcl-1)/(pow(1+ICIT/KIcl_ICIT,nIcl)+LIcl*pow(1+PEP/KIcl_PEP+GAP/KIcl_3PG+aKG/KIcl_aKG,nIcl))

		return rate

class vE_Ms_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KMs_GOX_AcCoA','KMs_GOX','kMs_cat','KMs_AcCoA']
		self.reaction_substrate_names = ['AcCoA','GOX','Ms']
		self.substrates = ['AcCoA','GOX']
		self.products = ['MAL']


	def calculate_rate(self, substrates, parameters):
		AcCoA = substrates[0]
		GOX = substrates[1]
		Ms = substrates[2]


		KMs_GOX_AcCoA = parameters[0]
		KMs_GOX = parameters[1]
		kMs_cat = parameters[2]
		KMs_AcCoA = parameters[3]



		rate=Ms*kMs_cat*GOX*AcCoA/(KMs_GOX_AcCoA*KMs_AcCoA+KMs_AcCoA*GOX+KMs_GOX*AcCoA+GOX*AcCoA)

		return rate

class vE_AceKki_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kAceKki_cat','LAceK','KAceK_OAA','nAceK','KAceK_Icdh']
		self.reaction_substrate_names = ['AceK','Icdh','OAA']
		self.substrates = ['ICDH','ATP']
		self.products = ['ICDHP','ADP']


	def calculate_rate(self, substrates, parameters):
		AceK = substrates[0]
		Icdh = substrates[1]
		OAA = substrates[2]


		kAceKki_cat = parameters[0]
		LAceK = parameters[1]
		KAceK_OAA = parameters[2]
		nAceK = parameters[3]
		KAceK_Icdh = parameters[4]



		rate=AceK*kAceKki_cat*Icdh/KAceK_Icdh*pow(1+Icdh/KAceK_Icdh,nAceK-1)/(pow(1+Icdh/KAceK_Icdh,nAceK)+LAceK*pow(1+OAA/KAceK_OAA,nAceK))

		return rate

class vE_AceKph_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['LAceKph','KAceK_IcdhP','nAceKph','KAceKph_OAA','kAceKph_cat']
		self.reaction_substrate_names = ['AceK','OAA','IcdhP']
		self.substrates = ['ICDHP']
		self.products = ['ICDH']


	def calculate_rate(self, substrates, parameters):
		AceK = substrates[0]
		OAA = substrates[1]
		IcdhP = substrates[2]


		LAceKph = parameters[0]
		KAceK_IcdhP = parameters[1]
		nAceKph = parameters[2]
		KAceKph_OAA = parameters[3]
		kAceKph_cat = parameters[4]



		rate=AceK*kAceKph_cat*IcdhP/KAceK_IcdhP*pow(1+IcdhP/KAceK_IcdhP,nAceKph-1)/(pow(1+IcdhP/KAceK_IcdhP,nAceKph)+LAceKph/pow(1+OAA/KAceKph_OAA,nAceKph))

		return rate

class vE_G6pdh_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KG6pdh_NADPH_nadpinh','KG6pdh_NADP','vG6pdh_max','KG6pdh_NADPH_g6pinh','KG6pdh_G6P']
		self.reaction_substrate_names = ['G6P','NADP','NADPH']
		self.substrates = ['G6P']
		self.products = ['sixPGL']


	def calculate_rate(self, substrates, parameters):
		G6P = substrates[0]
		NADP = substrates[1]
		NADPH = substrates[2]


		KG6pdh_NADPH_nadpinh = parameters[0]
		KG6pdh_NADP = parameters[1]
		vG6pdh_max = parameters[2]
		KG6pdh_NADPH_g6pinh = parameters[3]
		KG6pdh_G6P = parameters[4]



		rate=vG6pdh_max*G6P*NADP/((G6P+KG6pdh_G6P)*(1+NADPH/KG6pdh_NADPH_g6pinh)*(KG6pdh_NADP*(1+NADPH/KG6pdh_NADPH_nadpinh)+NADP))

		return rate

class vE_Pgl_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KPgl_eq','KPgl_h1','KPgl_6PG_m','KPgl_6PGL_m','vPgl_max','KPgl_h2']
		self.reaction_substrate_names = ['ATP','pH','PYR','sixPG','EIIAP','sixPGL','FBP','cAMP']
		self.substrates = ['sixPGL']
		self.products = ['sixPG']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		sixPG = substrates[3]
		EIIAP = substrates[4]
		sixPGL = substrates[5]
		FBP = substrates[6]
		cAMP = substrates[7]


		KPgl_eq = parameters[0]
		KPgl_h1 = parameters[1]
		KPgl_6PG_m = parameters[2]
		KPgl_6PGL_m = parameters[3]
		vPgl_max = parameters[4]
		KPgl_h2 = parameters[5]



		H=pow(10,-pH)*1e+3
		rate=vPgl_max*(sixPGL-sixPG/KPgl_eq)/((1+H/KPgl_h1+KPgl_h2/H)*(KPgl_6PGL_m+sixPGL+KPgl_6PGL_m/KPgl_6PG_m*sixPG))

		return rate

class vE_Edd_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KEdd_eq','pH_Edd_m','KEdd_KDPG_m','KEdd_6PG_m','vEdd_max','pK_Edd']
		self.reaction_substrate_names = ['KDPG','pH','sixPG']
		self.substrates = ['sixPG']
		self.products = ['KDPG']


	def calculate_rate(self, substrates, parameters):
		KDPG = substrates[0]
		pH = substrates[1]
		sixPG = substrates[2]


		KEdd_eq = parameters[0]
		pH_Edd_m = parameters[1]
		KEdd_KDPG_m = parameters[2]
		KEdd_6PG_m = parameters[3]
		vEdd_max = parameters[4]
		pK_Edd = parameters[5]


		QEdd_pH=1+2*pow(10,pH_Edd_m-pK_Edd)/(1+pow(10,pH-pK_Edd)+pow(10,2*pH_Edd_m-pH-pK_Edd))

		rate=vEdd_max*QEdd_pH*(sixPG-KDPG/KEdd_eq)/(KEdd_6PG_m+sixPG+KEdd_6PG_m*KDPG/KEdd_KDPG_m)

		return rate

class vE_Eda_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KEda_eq','vEda_max','pH_Eda_m','KEda_KDPG_m','KEda_GAP_m','KEda_PYR_m','pK_Eda']
		self.reaction_substrate_names = ['PYR','GAP','pH','KDPG']
		self.substrates = ['KDPG']
		self.products = ['GAP','PYR']


	def calculate_rate(self, substrates, parameters):
		PYR = substrates[0]
		GAP = substrates[1]
		pH = substrates[2]
		KDPG = substrates[3]


		KEda_eq = parameters[0]
		vEda_max = parameters[1]
		pH_Eda_m = parameters[2]
		KEda_KDPG_m = parameters[3]
		KEda_GAP_m = parameters[4]
		KEda_PYR_m = parameters[5]
		pK_Eda = parameters[6]


		QEda_pH=1+2*pow(10,pH_Eda_m-pK_Eda)/(1+pow(10,pH-pK_Eda)+pow(10,2*pH_Eda_m-pH-pK_Eda))

		rate=vEda_max*QEda_pH*(KDPG-GAP*PYR/KEda_eq)/(KEda_KDPG_m+KDPG+KEda_KDPG_m*(PYR/KEda_PYR_m+GAP/KEda_GAP_m+PYR*GAP/(KEda_PYR_m*KEda_GAP_m)))

		return rate

class vE_6Pgdh_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['K6Pgdh_NADPH_inh','v6Pgdh_max','K6Pgdh_NADP','K6Pgdh_6PG','K6Pgdh_ATP_inh']
		self.reaction_substrate_names = ['ATP','sixPG','NADP','NADPH']
		self.substrates = ['sixPG']
		self.products = ['RU5P']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		sixPG = substrates[1]
		NADP = substrates[2]
		NADPH = substrates[3]


		K6Pgdh_NADPH_inh = parameters[0]
		v6Pgdh_max = parameters[1]
		K6Pgdh_NADP = parameters[2]
		K6Pgdh_6PG = parameters[3]
		K6Pgdh_ATP_inh = parameters[4]



		rate=v6Pgdh_max*sixPG*NADP/((sixPG+K6Pgdh_6PG)*(NADP+K6Pgdh_NADP*(1+NADPH/K6Pgdh_NADPH_inh)*(1+ATP/K6Pgdh_ATP_inh)))

		return rate

class vE_R5pi_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['vR5pi_max','KR5pi_eq']
		self.reaction_substrate_names = ['RU5P','R5P']
		self.substrates = ['RU5P']
		self.products = ['R5P']


	def calculate_rate(self, substrates, parameters):
		RU5P = substrates[0]
		R5P = substrates[1]


		vR5pi_max = parameters[0]
		KR5pi_eq = parameters[1]



		rate=vR5pi_max*(RU5P-R5P/KR5pi_eq)

		return rate

class vE_Rpe_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KRpe_eq','vRpe_max']
		self.reaction_substrate_names = ['X5P','RU5P']
		self.substrates = ['RU5P']
		self.products = ['X5P']


	def calculate_rate(self, substrates, parameters):
		X5P = substrates[0]
		RU5P = substrates[1]


		KRpe_eq = parameters[0]
		vRpe_max = parameters[1]



		rate=vRpe_max*(RU5P-X5P/KRpe_eq)

		return rate

class vE_Tkt1_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KTkt1_eq','vTkt1_max']
		self.reaction_substrate_names = ['X5P','GAP','S7P','R5P']
		self.substrates = ['R5P','X5P']
		self.products = ['GAP','S7P']


	def calculate_rate(self, substrates, parameters):
		X5P = substrates[0]
		GAP = substrates[1]
		S7P = substrates[2]
		R5P = substrates[3]


		KTkt1_eq = parameters[0]
		vTkt1_max = parameters[1]



		rate=vTkt1_max*(R5P*X5P-S7P*GAP/KTkt1_eq)

		return rate

class vE_Tkt2_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['vTkt2_max','KTkt2_eq']
		self.reaction_substrate_names = ['X5P','E4P','GAP','F6P']
		self.substrates = ['X5P','E4P']
		self.products = ['F6P','GAP']


	def calculate_rate(self, substrates, parameters):
		X5P = substrates[0]
		E4P = substrates[1]
		GAP = substrates[2]
		F6P = substrates[3]


		vTkt2_max = parameters[0]
		KTkt2_eq = parameters[1]



		rate=vTkt2_max*(X5P*E4P-F6P*GAP/KTkt2_eq)

		return rate

class vE_Tal_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KTal_eq','vTal_max']
		self.reaction_substrate_names = ['E4P','GAP','S7P','F6P']
		self.substrates = ['GAP','S7P']
		self.products = ['F6P','E4P']


	def calculate_rate(self, substrates, parameters):
		E4P = substrates[0]
		GAP = substrates[1]
		S7P = substrates[2]
		F6P = substrates[3]


		KTal_eq = parameters[0]
		vTal_max = parameters[1]



		rate=vTal_max*(GAP*S7P-E4P*F6P/KTal_eq)

		return rate

class vE_Cya_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KCya_EIIAP','vCya_max']
		self.reaction_substrate_names = ['EIIAP']
		self.substrates = ['ATP']
		self.products = ['cAMP']


	def calculate_rate(self, substrates, parameters):
		EIIAP = substrates[0]


		KCya_EIIAP = parameters[0]
		vCya_max = parameters[1]



		rate=vCya_max*EIIAP/(EIIAP+KCya_EIIAP)

		return rate

class vE_cAMPdegr_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['vcAMPdegr_max','KcAMPdegr_cAMP']
		self.reaction_substrate_names = ['cAMP']
		self.substrates = ['cAMP']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		cAMP = substrates[0]


		vcAMPdegr_max = parameters[0]
		KcAMPdegr_cAMP = parameters[1]



		rate=vcAMPdegr_max*cAMP/(cAMP+KcAMPdegr_cAMP)

		return rate

class OP_NADH_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['K_GDH_Keq','Kakgdh_SUC_I','K_GDH_KmNADH','KMdh_eq','Kakgdh_CoA_m','KMdh_NAD_II','KMdh_NAD_I','KMdh_NAD_m','Kakgdh_aKG_I','KMdh_MAL_I','Kakgdh_aKG_m','kMdh1_cat','Kakgdh_Z','KMdh_OAA_I','kMdh2_cat','K_GDH_KmGAP','KPdh_AcCoA_m','KMdh_OAA_II','KMdh_OAA_m','kPdh_cat','K_GDH_KmBPG','KMdh_MAL_m','KPdh_NAD_m','KMdh_NADH_m','KPdh_CoA_m','kakgdh_cat','K_GDH_KmP','KPdh_i','Kakgdh_NADH_I','KPdh_PYR_m','Kakgdh_NAD_m','v_GDH_Vmax','KPdh_NADH_m','KMdh_NADH_I','POratio','K_GDH_KmNAD']
		self.reaction_substrate_names = ['NAD','BPG','AcCoA','MAL','P','aKG','akgdh','OAA','PYR','Pdh','SUC','NADH','GAP','CoA','Mdh']
		self.substrates = ['ADP']
		self.products = ['ATP']


	def calculate_rate(self, substrates, parameters):
		NAD = substrates[0]
		BPG = substrates[1]
		AcCoA = substrates[2]
		MAL = substrates[3]
		P = substrates[4]
		aKG = substrates[5]
		akgdh = substrates[6]
		OAA = substrates[7]
		PYR = substrates[8]
		Pdh = substrates[9]
		SUC = substrates[10]
		NADH = substrates[11]
		GAP = substrates[12]
		CoA = substrates[13]
		Mdh = substrates[14]


		K_GDH_Keq = parameters[0]
		Kakgdh_SUC_I = parameters[1]
		K_GDH_KmNADH = parameters[2]
		KMdh_eq = parameters[3]
		Kakgdh_CoA_m = parameters[4]
		KMdh_NAD_II = parameters[5]
		KMdh_NAD_I = parameters[6]
		KMdh_NAD_m = parameters[7]
		Kakgdh_aKG_I = parameters[8]
		KMdh_MAL_I = parameters[9]
		Kakgdh_aKG_m = parameters[10]
		kMdh1_cat = parameters[11]
		Kakgdh_Z = parameters[12]
		KMdh_OAA_I = parameters[13]
		kMdh2_cat = parameters[14]
		K_GDH_KmGAP = parameters[15]
		KPdh_AcCoA_m = parameters[16]
		KMdh_OAA_II = parameters[17]
		KMdh_OAA_m = parameters[18]
		kPdh_cat = parameters[19]
		K_GDH_KmBPG = parameters[20]
		KMdh_MAL_m = parameters[21]
		KPdh_NAD_m = parameters[22]
		KMdh_NADH_m = parameters[23]
		KPdh_CoA_m = parameters[24]
		kakgdh_cat = parameters[25]
		K_GDH_KmP = parameters[26]
		KPdh_i = parameters[27]
		Kakgdh_NADH_I = parameters[28]
		KPdh_PYR_m = parameters[29]
		Kakgdh_NAD_m = parameters[30]
		v_GDH_Vmax = parameters[31]
		KPdh_NADH_m = parameters[32]
		KMdh_NADH_I = parameters[33]
		POratio = parameters[34]
		K_GDH_KmNAD = parameters[35]



		vE_Gdh=v_GDH_Vmax*(P*GAP*NAD-BPG*NADH/K_GDH_Keq)/(K_GDH_KmP*K_GDH_KmGAP*K_GDH_KmNAD)/((1+P/K_GDH_KmP)*(1+GAP/K_GDH_KmGAP)*(1+NAD/K_GDH_KmNAD)+(1+BPG/K_GDH_KmBPG)*(1+NADH/K_GDH_KmNADH)-1)
		vE_Pdh=Pdh*kPdh_cat*(1/(1+KPdh_i*NADH/NAD))*(PYR/KPdh_PYR_m)*(NAD/KPdh_NAD_m)*(CoA/KPdh_CoA_m)/((1+PYR/KPdh_PYR_m)*(1+NAD/KPdh_NAD_m+NADH/KPdh_NADH_m)*(1+CoA/KPdh_CoA_m+AcCoA/KPdh_AcCoA_m))
		vMdh1_max=Mdh*kMdh1_cat
		vMdh2_max=Mdh*kMdh2_cat
		vE_Mdh=vMdh1_max*vMdh2_max*(NAD*MAL-NADH*OAA/KMdh_eq)/(KMdh_NAD_I*KMdh_MAL_m*vMdh2_max+KMdh_MAL_m*vMdh2_max*NAD+KMdh_NAD_m*vMdh2_max*MAL+vMdh2_max*NAD*MAL+KMdh_OAA_m*vMdh1_max*NADH/KMdh_eq+KMdh_NADH_m*vMdh1_max*OAA/KMdh_eq+vMdh1_max*NADH*OAA/KMdh_eq+vMdh1_max*KMdh_OAA_m*NAD*NADH/(KMdh_eq*KMdh_NAD_I)+vMdh2_max*KMdh_NAD_m*MAL*OAA/KMdh_OAA_I+vMdh2_max*NAD*MAL*NADH/KMdh_NADH_I+vMdh1_max*MAL*NADH*OAA/(KMdh_eq*KMdh_MAL_I)+vMdh2_max*NAD*MAL*OAA/KMdh_OAA_II+vMdh1_max*NAD*NADH*OAA/(KMdh_NAD_II*KMdh_eq)+KMdh_NAD_I*vMdh2_max*NAD*MAL*NADH*OAA/(KMdh_NAD_II*KMdh_OAA_m*KMdh_NADH_I))
		vE_akgdh=akgdh*kakgdh_cat*aKG*CoA*NAD/(Kakgdh_NAD_m*aKG*CoA+Kakgdh_CoA_m*aKG*NAD+Kakgdh_aKG_m*CoA*NAD+aKG*CoA*NAD+Kakgdh_aKG_m*Kakgdh_Z*SUC*NADH/Kakgdh_SUC_I+Kakgdh_NAD_m*aKG*CoA*NADH/Kakgdh_NADH_I+Kakgdh_CoA_m*aKG*NAD*SUC/Kakgdh_SUC_I+Kakgdh_aKG_m*Kakgdh_Z*aKG*SUC*NADH/(Kakgdh_aKG_I*Kakgdh_SUC_I))
		rate=(vE_Gdh+vE_Pdh+vE_akgdh+vE_Mdh)*POratio

		return rate

class OP_FADH2_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KSdh_eq','KSdh_SUC_m','POratio_prime','kSdh1_cat','kSdh2_cat']
		self.reaction_substrate_names = ['SUC','FUM','Sdh']
		self.substrates = ['ADP']
		self.products = ['ATP']


	def calculate_rate(self, substrates, parameters):
		SUC = substrates[0]
		FUM = substrates[1]
		Sdh = substrates[2]


		KSdh_eq = parameters[0]
		KSdh_SUC_m = parameters[1]
		POratio_prime = parameters[2]
		kSdh1_cat = parameters[3]
		kSdh2_cat = parameters[4]



		vSdh1_max=Sdh*kSdh1_cat
		vSdh2_max=Sdh*kSdh2_cat
		vE_Sdh=vSdh1_max*vSdh2_max*(SUC-FUM/KSdh_eq)/(KSdh_SUC_m*vSdh2_max+vSdh2_max*SUC+vSdh1_max*FUM/KSdh_eq)
		rate=vE_Sdh*POratio_prime

		return rate

class mu_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP']
		self.substrates = []
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]


		kATP = parameters[0]



		rate=kATP*ATP

		return rate

class vgrowth_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP','X']
		self.substrates = []
		self.products = ['X']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]
		X = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*X

		return rate

class vG_glk_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['vglk_Cra_unbound','Cratotal','nCraFBP','KCraFBP','kATP','Kglk_Cra','vglk_Cra_bound']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['Glk']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		vglk_Cra_unbound = parameters[0]
		Cratotal = parameters[1]
		nCraFBP = parameters[2]
		KCraFBP = parameters[3]
		kATP = parameters[4]
		Kglk_Cra = parameters[5]
		vglk_Cra_bound = parameters[6]



		mu=kATP*ATP
		CraFBP=Cratotal*pow(FBP,nCraFBP)/(pow(FBP,nCraFBP)+pow(KCraFBP,nCraFBP))
		Cra=Cratotal-CraFBP
		mu=kATP*ATP
		rate=mu*((1-Cra/(Cra+Kglk_Cra))*vglk_Cra_unbound+Cra/(Cra+Kglk_Cra)*vglk_Cra_bound)

		return rate

class vG_pfkA_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['Cratotal','vpfkA_Cra_bound','nCraFBP','vpfkA_Cra_unbound','KpfkA_Cra','KCraFBP','kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['Pfk']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		Cratotal = parameters[0]
		vpfkA_Cra_bound = parameters[1]
		nCraFBP = parameters[2]
		vpfkA_Cra_unbound = parameters[3]
		KpfkA_Cra = parameters[4]
		KCraFBP = parameters[5]
		kATP = parameters[6]



		mu=kATP*ATP
		CraFBP=Cratotal*pow(FBP,nCraFBP)/(pow(FBP,nCraFBP)+pow(KCraFBP,nCraFBP))
		Cra=Cratotal-CraFBP
		mu=kATP*ATP
		rate=mu*((1-Cra/(Cra+KpfkA_Cra))*vpfkA_Cra_unbound+Cra/(Cra+KpfkA_Cra)*vpfkA_Cra_bound)

		return rate

class vG_fbp_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['vfbp_Cra_unbound','Cratotal','nCraFBP','Kfbp_Cra','KCraFBP','kATP','vfbp_Cra_bound']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['Fbp']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		vfbp_Cra_unbound = parameters[0]
		Cratotal = parameters[1]
		nCraFBP = parameters[2]
		Kfbp_Cra = parameters[3]
		KCraFBP = parameters[4]
		kATP = parameters[5]
		vfbp_Cra_bound = parameters[6]



		mu=kATP*ATP
		CraFBP=Cratotal*pow(FBP,nCraFBP)/(pow(FBP,nCraFBP)+pow(KCraFBP,nCraFBP))
		Cra=Cratotal-CraFBP
		mu=kATP*ATP
		rate=mu*((1-Cra/(Cra+Kfbp_Cra))*vfbp_Cra_unbound+Cra/(Cra+Kfbp_Cra)*vfbp_Cra_bound)

		return rate

class vG_fbaA_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KfbaA_Cra','vfbaA_Crp_bound','Cratotal','nCrpcAMP','vfbaA_Cra_unbound','nCraFBP','KfbaA_Crp','Crptotal','KCraFBP','kATP','vfbaA_Cra_bound','vfbaA_Crp_unbound','KCrpcAMP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['Fba']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		KfbaA_Cra = parameters[0]
		vfbaA_Crp_bound = parameters[1]
		Cratotal = parameters[2]
		nCrpcAMP = parameters[3]
		vfbaA_Cra_unbound = parameters[4]
		nCraFBP = parameters[5]
		KfbaA_Crp = parameters[6]
		Crptotal = parameters[7]
		KCraFBP = parameters[8]
		kATP = parameters[9]
		vfbaA_Cra_bound = parameters[10]
		vfbaA_Crp_unbound = parameters[11]
		KCrpcAMP = parameters[12]



		mu=kATP*ATP
		CrpcAMP=Crptotal*pow(cAMP,nCrpcAMP)/(pow(cAMP,nCrpcAMP)+pow(KCrpcAMP,nCrpcAMP))
		CraFBP=Cratotal*pow(FBP,nCraFBP)/(pow(FBP,nCraFBP)+pow(KCraFBP,nCraFBP))
		Cra=Cratotal-CraFBP
		mu=kATP*ATP
		rate=mu*((1-Cra/(Cra+KfbaA_Cra))*vfbaA_Cra_unbound+Cra/(Cra+KfbaA_Cra)*vfbaA_Cra_bound+(1-CrpcAMP/(CrpcAMP+KfbaA_Crp))*vfbaA_Crp_unbound+CrpcAMP/(CrpcAMP+KfbaA_Crp)*vfbaA_Crp_bound)

		return rate

class vG_gapA_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['Cratotal','nCrpcAMP','vgapA_Cra_bound','vgapA_Cra_unbound','nCraFBP','KgapA_Cra','KgapA_Crp','Crptotal','KCraFBP','kATP','vgapA_Crp_unbound','vgapA_Crp_bound','KCrpcAMP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['GAPDH']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		Cratotal = parameters[0]
		nCrpcAMP = parameters[1]
		vgapA_Cra_bound = parameters[2]
		vgapA_Cra_unbound = parameters[3]
		nCraFBP = parameters[4]
		KgapA_Cra = parameters[5]
		KgapA_Crp = parameters[6]
		Crptotal = parameters[7]
		KCraFBP = parameters[8]
		kATP = parameters[9]
		vgapA_Crp_unbound = parameters[10]
		vgapA_Crp_bound = parameters[11]
		KCrpcAMP = parameters[12]



		mu=kATP*ATP
		CrpcAMP=Crptotal*pow(cAMP,nCrpcAMP)/(pow(cAMP,nCrpcAMP)+pow(KCrpcAMP,nCrpcAMP))
		CraFBP=Cratotal*pow(FBP,nCraFBP)/(pow(FBP,nCraFBP)+pow(KCraFBP,nCraFBP))
		Cra=Cratotal-CraFBP
		mu=kATP*ATP
		rate=mu*((1-Cra/(Cra+KgapA_Cra))*vgapA_Cra_unbound+Cra/(Cra+KgapA_Cra)*vgapA_Cra_bound+(1-CrpcAMP/(CrpcAMP+KgapA_Crp))*vgapA_Crp_unbound+CrpcAMP/(CrpcAMP+KgapA_Crp)*vgapA_Crp_bound)

		return rate

class vG_pykF_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['Cratotal','nCraFBP','vpykF_Cra_unbound','KCraFBP','kATP','KpykF_Cra','vpykF_Cra_bound']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['Pyk']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		Cratotal = parameters[0]
		nCraFBP = parameters[1]
		vpykF_Cra_unbound = parameters[2]
		KCraFBP = parameters[3]
		kATP = parameters[4]
		KpykF_Cra = parameters[5]
		vpykF_Cra_bound = parameters[6]



		mu=kATP*ATP
		CraFBP=Cratotal*pow(FBP,nCraFBP)/(pow(FBP,nCraFBP)+pow(KCraFBP,nCraFBP))
		Cra=Cratotal-CraFBP
		mu=kATP*ATP
		rate=mu*((1-Cra/(Cra+KpykF_Cra))*vpykF_Cra_unbound+Cra/(Cra+KpykF_Cra)*vpykF_Cra_bound)

		return rate

class vG_ppsA_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['Cratotal','nCraFBP','vppsA_Cra_bound','KCraFBP','kATP','vppsA_Cra_unbound','KppsA_Cra']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['Pps']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		Cratotal = parameters[0]
		nCraFBP = parameters[1]
		vppsA_Cra_bound = parameters[2]
		KCraFBP = parameters[3]
		kATP = parameters[4]
		vppsA_Cra_unbound = parameters[5]
		KppsA_Cra = parameters[6]



		mu=kATP*ATP
		CraFBP=Cratotal*pow(FBP,nCraFBP)/(pow(FBP,nCraFBP)+pow(KCraFBP,nCraFBP))
		Cra=Cratotal-CraFBP
		mu=kATP*ATP
		rate=mu*((1-Cra/(Cra+KppsA_Cra))*vppsA_Cra_unbound+Cra/(Cra+KppsA_Cra)*vppsA_Cra_bound)

		return rate

class vG_lpd_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['Klpd_PdhR','KPdhRPYR','PdhRtotal','nPdhRPYR','vlpd_PdhR_bound','kATP','vlpd_PdhR_unbound']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['PDH']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		Klpd_PdhR = parameters[0]
		KPdhRPYR = parameters[1]
		PdhRtotal = parameters[2]
		nPdhRPYR = parameters[3]
		vlpd_PdhR_bound = parameters[4]
		kATP = parameters[5]
		vlpd_PdhR_unbound = parameters[6]



		mu=kATP*ATP
		mu=kATP*ATP
		PdhRPYR=PdhRtotal*pow(PYR,nPdhRPYR)/(pow(PYR,nPdhRPYR)+pow(KPdhRPYR,nPdhRPYR))
		PdhR=PdhRtotal-PdhRPYR
		rate=mu*((1-PdhR/(PdhR+Klpd_PdhR))*vlpd_PdhR_unbound+PdhR/(PdhR+Klpd_PdhR)*vlpd_PdhR_bound)

		return rate

class vG_acs_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['nCrpcAMP','nacs','Kacs_Crp','vacs_Crp_bound','Crptotal','kATP','vacs_Crp_unbound','KCrpcAMP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['Acs']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		nCrpcAMP = parameters[0]
		nacs = parameters[1]
		Kacs_Crp = parameters[2]
		vacs_Crp_bound = parameters[3]
		Crptotal = parameters[4]
		kATP = parameters[5]
		vacs_Crp_unbound = parameters[6]
		KCrpcAMP = parameters[7]



		mu=kATP*ATP
		CrpcAMP=Crptotal*pow(cAMP,nCrpcAMP)/(pow(cAMP,nCrpcAMP)+pow(KCrpcAMP,nCrpcAMP))
		mu=kATP*ATP
		rate=mu*((1-pow(CrpcAMP,nacs)/(pow(CrpcAMP,nacs)+pow(Kacs_Crp,nacs)))*vacs_Crp_unbound+pow(CrpcAMP,nacs)/(pow(CrpcAMP,nacs)+pow(Kacs_Crp,nacs))*vacs_Crp_bound)

		return rate

class vG_gltA_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['ngltA','nCrpcAMP','vgltA_Crp_bound','KgltA_Crp','Crptotal','kATP','vgltA_Crp_unbound','KCrpcAMP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['CS']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		ngltA = parameters[0]
		nCrpcAMP = parameters[1]
		vgltA_Crp_bound = parameters[2]
		KgltA_Crp = parameters[3]
		Crptotal = parameters[4]
		kATP = parameters[5]
		vgltA_Crp_unbound = parameters[6]
		KCrpcAMP = parameters[7]



		mu=kATP*ATP
		CrpcAMP=Crptotal*pow(cAMP,nCrpcAMP)/(pow(cAMP,nCrpcAMP)+pow(KCrpcAMP,nCrpcAMP))
		mu=kATP*ATP
		rate=mu*((1-pow(CrpcAMP,ngltA)/(pow(CrpcAMP,ngltA)+pow(KgltA_Crp,ngltA)))*vgltA_Crp_unbound+pow(CrpcAMP,ngltA)/(pow(CrpcAMP,ngltA)+pow(KgltA_Crp,ngltA))*vgltA_Crp_bound)

		return rate

class vG_icdA_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['Cratotal','nCraFBP','KCraFBP','kATP','vicdA_Cra_unbound','vicdA_Cra_bound','KicdA_Cra']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['ICDH']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		Cratotal = parameters[0]
		nCraFBP = parameters[1]
		KCraFBP = parameters[2]
		kATP = parameters[3]
		vicdA_Cra_unbound = parameters[4]
		vicdA_Cra_bound = parameters[5]
		KicdA_Cra = parameters[6]



		mu=kATP*ATP
		CraFBP=Cratotal*pow(FBP,nCraFBP)/(pow(FBP,nCraFBP)+pow(KCraFBP,nCraFBP))
		Cra=Cratotal-CraFBP
		mu=kATP*ATP
		rate=mu*((1-Cra/(Cra+KicdA_Cra))*vicdA_Cra_unbound+Cra/(Cra+KicdA_Cra)*vicdA_Cra_bound)

		return rate

class vG_sucAB_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['nsucAB','vsucAB_Crp_bound','nCrpcAMP','Crptotal','kATP','KsucAB_Crp','vsucAB_Crp_unbound','KCrpcAMP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['aKGDH']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		nsucAB = parameters[0]
		vsucAB_Crp_bound = parameters[1]
		nCrpcAMP = parameters[2]
		Crptotal = parameters[3]
		kATP = parameters[4]
		KsucAB_Crp = parameters[5]
		vsucAB_Crp_unbound = parameters[6]
		KCrpcAMP = parameters[7]



		mu=kATP*ATP
		CrpcAMP=Crptotal*pow(cAMP,nCrpcAMP)/(pow(cAMP,nCrpcAMP)+pow(KCrpcAMP,nCrpcAMP))
		mu=kATP*ATP
		rate=mu*((1-pow(CrpcAMP,nsucAB)/(pow(CrpcAMP,nsucAB)+pow(KsucAB_Crp,nsucAB)))*vsucAB_Crp_unbound+pow(CrpcAMP,nsucAB)/(pow(CrpcAMP,nsucAB)+pow(KsucAB_Crp,nsucAB))*vsucAB_Crp_bound)

		return rate

class vG_sdhCDAB_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['nsdhCDAB','nCrpcAMP','Crptotal','vsdhCDAB_Crp_unbound','kATP','KsdhCDAB_Crp','vsdhCDAB_Crp_bound','KCrpcAMP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['SDH']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		nsdhCDAB = parameters[0]
		nCrpcAMP = parameters[1]
		Crptotal = parameters[2]
		vsdhCDAB_Crp_unbound = parameters[3]
		kATP = parameters[4]
		KsdhCDAB_Crp = parameters[5]
		vsdhCDAB_Crp_bound = parameters[6]
		KCrpcAMP = parameters[7]



		mu=kATP*ATP
		CrpcAMP=Crptotal*pow(cAMP,nCrpcAMP)/(pow(cAMP,nCrpcAMP)+pow(KCrpcAMP,nCrpcAMP))
		mu=kATP*ATP
		rate=mu*((1-pow(CrpcAMP,nsdhCDAB)/(pow(CrpcAMP,nsdhCDAB)+pow(KsdhCDAB_Crp,nsdhCDAB)))*vsdhCDAB_Crp_unbound+pow(CrpcAMP,nsdhCDAB)/(pow(CrpcAMP,nsdhCDAB)+pow(KsdhCDAB_Crp,nsdhCDAB))*vsdhCDAB_Crp_bound)

		return rate

class vG_fumABC_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['nCrpcAMP','vfumABC_Crp_bound','vfumABC_Crp_unbound','Crptotal','kATP','nfumABC','KfumABC_Crp','KCrpcAMP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['Fum']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		nCrpcAMP = parameters[0]
		vfumABC_Crp_bound = parameters[1]
		vfumABC_Crp_unbound = parameters[2]
		Crptotal = parameters[3]
		kATP = parameters[4]
		nfumABC = parameters[5]
		KfumABC_Crp = parameters[6]
		KCrpcAMP = parameters[7]



		mu=kATP*ATP
		CrpcAMP=Crptotal*pow(cAMP,nCrpcAMP)/(pow(cAMP,nCrpcAMP)+pow(KCrpcAMP,nCrpcAMP))
		mu=kATP*ATP
		rate=mu*((1-pow(CrpcAMP,nfumABC)/(pow(CrpcAMP,nfumABC)+pow(KfumABC_Crp,nfumABC)))*vfumABC_Crp_unbound+pow(CrpcAMP,nfumABC)/(pow(CrpcAMP,nfumABC)+pow(KfumABC_Crp,nfumABC))*vfumABC_Crp_bound)

		return rate

class vG_mdh_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['vmdh_Crp_bound','nCrpcAMP','vmdh_Crp_unbound','Crptotal','kATP','Kmdh_Crp','KCrpcAMP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['MDH']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		vmdh_Crp_bound = parameters[0]
		nCrpcAMP = parameters[1]
		vmdh_Crp_unbound = parameters[2]
		Crptotal = parameters[3]
		kATP = parameters[4]
		Kmdh_Crp = parameters[5]
		KCrpcAMP = parameters[6]



		mu=kATP*ATP
		CrpcAMP=Crptotal*pow(cAMP,nCrpcAMP)/(pow(cAMP,nCrpcAMP)+pow(KCrpcAMP,nCrpcAMP))
		mu=kATP*ATP
		rate=mu*((1-CrpcAMP/(CrpcAMP+Kmdh_Crp))*vmdh_Crp_unbound+CrpcAMP/(CrpcAMP+Kmdh_Crp)*vmdh_Crp_bound)

		return rate

class vG_maeB_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','SS_MaeB']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['MaeB']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		kATP = parameters[0]
		SS_MaeB = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*SS_MaeB

		return rate

class vG_pckA_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['Cratotal','nCraFBP','vpckA_Cra_bound','vpckA_Cra_unbound','KpckA_Cra','KCraFBP','kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['Pck']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		Cratotal = parameters[0]
		nCraFBP = parameters[1]
		vpckA_Cra_bound = parameters[2]
		vpckA_Cra_unbound = parameters[3]
		KpckA_Cra = parameters[4]
		KCraFBP = parameters[5]
		kATP = parameters[6]



		mu=kATP*ATP
		CraFBP=Cratotal*pow(FBP,nCraFBP)/(pow(FBP,nCraFBP)+pow(KCraFBP,nCraFBP))
		Cra=Cratotal-CraFBP
		mu=kATP*ATP
		rate=mu*((1-Cra/(Cra+KpckA_Cra))*vpckA_Cra_unbound+Cra/(Cra+KpckA_Cra)*vpckA_Cra_bound)

		return rate

class vG_ppc_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['SS_Ppc','kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = []
		self.products = ['Ppc']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		SS_Ppc = parameters[0]
		kATP = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*SS_Ppc

		return rate

class vG_aceA_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KaceBAK_PYRprime','Kmu','KCrpcAMP','Cratotal','nCrpcAMP','LaceBAK','KaceBAK_GOX','Crptotal','KaceBAK_Cra','kaceBAK_cat_IclR','KaceBAK_PYR','KaceBAK_DNA','kATP','IclRtotal','KaceBAK_Crp','vaceBAK_Cra_unbound','vaceBAK_Crp_unbound','nCraFBP','vaceBAK_Crp_bound','vaceBAK_Cra_bound','KCraFBP','n_mu']
		self.reaction_substrate_names = ['ATP','pH','PYR','aceBAK_DNA','EIIAP','GOX','FBP','cAMP']
		self.substrates = []
		self.products = ['Icl']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		aceBAK_DNA = substrates[3]
		EIIAP = substrates[4]
		GOX = substrates[5]
		FBP = substrates[6]
		cAMP = substrates[7]


		KaceBAK_PYRprime = parameters[0]
		Kmu = parameters[1]
		KCrpcAMP = parameters[2]
		Cratotal = parameters[3]
		nCrpcAMP = parameters[4]
		LaceBAK = parameters[5]
		KaceBAK_GOX = parameters[6]
		Crptotal = parameters[7]
		KaceBAK_Cra = parameters[8]
		kaceBAK_cat_IclR = parameters[9]
		KaceBAK_PYR = parameters[10]
		KaceBAK_DNA = parameters[11]
		kATP = parameters[12]
		IclRtotal = parameters[13]
		KaceBAK_Crp = parameters[14]
		vaceBAK_Cra_unbound = parameters[15]
		vaceBAK_Crp_unbound = parameters[16]
		nCraFBP = parameters[17]
		vaceBAK_Crp_bound = parameters[18]
		vaceBAK_Cra_bound = parameters[19]
		KCraFBP = parameters[20]
		n_mu = parameters[21]



		mu=kATP*ATP
		CrpcAMP=Crptotal*pow(cAMP,nCrpcAMP)/(pow(cAMP,nCrpcAMP)+pow(KCrpcAMP,nCrpcAMP))
		mu=kATP*ATP
		CraFBP=Cratotal*pow(FBP,nCraFBP)/(pow(FBP,nCraFBP)+pow(KCraFBP,nCraFBP))
		Cra=Cratotal-CraFBP
		rate=mu*pow(Kmu,n_mu)/(pow(mu,n_mu)+pow(Kmu,n_mu))*((1-Cra/(Cra+KaceBAK_Cra))*vaceBAK_Cra_unbound+Cra/(Cra+KaceBAK_Cra)*vaceBAK_Cra_bound+(1-CrpcAMP/(CrpcAMP+KaceBAK_Crp))*vaceBAK_Crp_unbound+CrpcAMP/(CrpcAMP+KaceBAK_Crp)*vaceBAK_Crp_bound+(1-aceBAK_DNA/KaceBAK_DNA*(1+PYR/KaceBAK_PYRprime)/(1+1/LaceBAK*(GOX/KaceBAK_GOX)*(1+GOX/KaceBAK_GOX)+aceBAK_DNA/KaceBAK_DNA+PYR/KaceBAK_PYR+aceBAK_DNA/KaceBAK_DNA*PYR/KaceBAK_PYRprime))*kaceBAK_cat_IclR*IclRtotal)

		return rate

class vG_aceB_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KaceBAK_PYRprime','Kmu','KCrpcAMP','Cratotal','nCrpcAMP','LaceBAK','KaceBAK_GOX','Crptotal','KaceBAK_Cra','kaceBAK_cat_IclR','KaceBAK_PYR','Factor_aceB','KaceBAK_DNA','kATP','IclRtotal','KaceBAK_Crp','vaceBAK_Cra_unbound','vaceBAK_Crp_unbound','nCraFBP','vaceBAK_Crp_bound','vaceBAK_Cra_bound','KCraFBP','n_mu']
		self.reaction_substrate_names = ['ATP','pH','PYR','aceBAK_DNA','EIIAP','GOX','FBP','cAMP']
		self.substrates = []
		self.products = ['MS']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		aceBAK_DNA = substrates[3]
		EIIAP = substrates[4]
		GOX = substrates[5]
		FBP = substrates[6]
		cAMP = substrates[7]


		KaceBAK_PYRprime = parameters[0]
		Kmu = parameters[1]
		KCrpcAMP = parameters[2]
		Cratotal = parameters[3]
		nCrpcAMP = parameters[4]
		LaceBAK = parameters[5]
		KaceBAK_GOX = parameters[6]
		Crptotal = parameters[7]
		KaceBAK_Cra = parameters[8]
		kaceBAK_cat_IclR = parameters[9]
		KaceBAK_PYR = parameters[10]
		Factor_aceB = parameters[11]
		KaceBAK_DNA = parameters[12]
		kATP = parameters[13]
		IclRtotal = parameters[14]
		KaceBAK_Crp = parameters[15]
		vaceBAK_Cra_unbound = parameters[16]
		vaceBAK_Crp_unbound = parameters[17]
		nCraFBP = parameters[18]
		vaceBAK_Crp_bound = parameters[19]
		vaceBAK_Cra_bound = parameters[20]
		KCraFBP = parameters[21]
		n_mu = parameters[22]



		CrpcAMP=Crptotal*pow(cAMP,nCrpcAMP)/(pow(cAMP,nCrpcAMP)+pow(KCrpcAMP,nCrpcAMP))
		mu=kATP*ATP
		CraFBP=Cratotal*pow(FBP,nCraFBP)/(pow(FBP,nCraFBP)+pow(KCraFBP,nCraFBP))
		Cra=Cratotal-CraFBP
		vG_aceA=mu*pow(Kmu,n_mu)/(pow(mu,n_mu)+pow(Kmu,n_mu))*((1-Cra/(Cra+KaceBAK_Cra))*vaceBAK_Cra_unbound+Cra/(Cra+KaceBAK_Cra)*vaceBAK_Cra_bound+(1-CrpcAMP/(CrpcAMP+KaceBAK_Crp))*vaceBAK_Crp_unbound+CrpcAMP/(CrpcAMP+KaceBAK_Crp)*vaceBAK_Crp_bound+(1-aceBAK_DNA/KaceBAK_DNA*(1+PYR/KaceBAK_PYRprime)/(1+1/LaceBAK*(GOX/KaceBAK_GOX)*(1+GOX/KaceBAK_GOX)+aceBAK_DNA/KaceBAK_DNA+PYR/KaceBAK_PYR+aceBAK_DNA/KaceBAK_DNA*PYR/KaceBAK_PYRprime))*kaceBAK_cat_IclR*IclRtotal)
		rate=Factor_aceB*vG_aceA

		return rate

class vG_aceK_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['KaceBAK_PYRprime','Kmu','KCrpcAMP','Cratotal','nCrpcAMP','LaceBAK','KaceBAK_GOX','Crptotal','KaceBAK_Cra','kaceBAK_cat_IclR','Factor_aceK','KaceBAK_PYR','KaceBAK_DNA','kATP','IclRtotal','KaceBAK_Crp','vaceBAK_Cra_unbound','vaceBAK_Crp_unbound','nCraFBP','vaceBAK_Crp_bound','vaceBAK_Cra_bound','KCraFBP','n_mu']
		self.reaction_substrate_names = ['ATP','pH','PYR','aceBAK_DNA','EIIAP','GOX','FBP','cAMP']
		self.substrates = []
		self.products = ['AceK']


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		aceBAK_DNA = substrates[3]
		EIIAP = substrates[4]
		GOX = substrates[5]
		FBP = substrates[6]
		cAMP = substrates[7]


		KaceBAK_PYRprime = parameters[0]
		Kmu = parameters[1]
		KCrpcAMP = parameters[2]
		Cratotal = parameters[3]
		nCrpcAMP = parameters[4]
		LaceBAK = parameters[5]
		KaceBAK_GOX = parameters[6]
		Crptotal = parameters[7]
		KaceBAK_Cra = parameters[8]
		kaceBAK_cat_IclR = parameters[9]
		Factor_aceK = parameters[10]
		KaceBAK_PYR = parameters[11]
		KaceBAK_DNA = parameters[12]
		kATP = parameters[13]
		IclRtotal = parameters[14]
		KaceBAK_Crp = parameters[15]
		vaceBAK_Cra_unbound = parameters[16]
		vaceBAK_Crp_unbound = parameters[17]
		nCraFBP = parameters[18]
		vaceBAK_Crp_bound = parameters[19]
		vaceBAK_Cra_bound = parameters[20]
		KCraFBP = parameters[21]
		n_mu = parameters[22]



		CrpcAMP=Crptotal*pow(cAMP,nCrpcAMP)/(pow(cAMP,nCrpcAMP)+pow(KCrpcAMP,nCrpcAMP))
		mu=kATP*ATP
		CraFBP=Cratotal*pow(FBP,nCraFBP)/(pow(FBP,nCraFBP)+pow(KCraFBP,nCraFBP))
		Cra=Cratotal-CraFBP
		vG_aceA=mu*pow(Kmu,n_mu)/(pow(mu,n_mu)+pow(Kmu,n_mu))*((1-Cra/(Cra+KaceBAK_Cra))*vaceBAK_Cra_unbound+Cra/(Cra+KaceBAK_Cra)*vaceBAK_Cra_bound+(1-CrpcAMP/(CrpcAMP+KaceBAK_Crp))*vaceBAK_Crp_unbound+CrpcAMP/(CrpcAMP+KaceBAK_Crp)*vaceBAK_Crp_bound+(1-aceBAK_DNA/KaceBAK_DNA*(1+PYR/KaceBAK_PYRprime)/(1+1/LaceBAK*(GOX/KaceBAK_GOX)*(1+GOX/KaceBAK_GOX)+aceBAK_DNA/KaceBAK_DNA+PYR/KaceBAK_PYR+aceBAK_DNA/KaceBAK_DNA*PYR/KaceBAK_PYRprime))*kaceBAK_cat_IclR*IclRtotal)
		rate=Factor_aceK*vG_aceA

		return rate

class vD_X_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['D']
		self.reaction_substrate_names = ['X']
		self.substrates = ['X']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		X = substrates[0]


		D = parameters[0]



		rate=D*X

		return rate

class vD_GLCfeed_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['D']
		self.reaction_substrate_names = ['GLCfeed']
		self.substrates = []
		self.products = ['GLCex']


	def calculate_rate(self, substrates, parameters):
		GLCfeed = substrates[0]


		D = parameters[0]



		rate=D*GLCfeed

		return rate

class vD_GLCex_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['D']
		self.reaction_substrate_names = ['GLCex']
		self.substrates = ['GLCex']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		GLCex = substrates[0]


		D = parameters[0]



		rate=D*GLCex

		return rate

class vD_GLC_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','GLC','FBP','cAMP']
		self.substrates = ['GLC']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		GLC = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*GLC

		return rate

class vD_G6P_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','G6P','EIIAP','FBP','cAMP']
		self.substrates = ['G6P']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		G6P = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*G6P

		return rate

class vD_F6P_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','F6P','FBP','cAMP']
		self.substrates = ['F6P']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		F6P = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*F6P

		return rate

class vD_FBP_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['FBP']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*FBP

		return rate

class vD_GAP_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','GAP','FBP','cAMP']
		self.substrates = ['GAP']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		GAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*GAP

		return rate

class vD_PEP_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PEP','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['PEP']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PEP = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*PEP

		return rate

class vD_PYR_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['PYR']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*PYR

		return rate

class vD_AcCoA_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['AcCoA','ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['AcCoA']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		AcCoA = substrates[0]
		ATP = substrates[1]
		pH = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*AcCoA

		return rate

class vD_AcP_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','AcP','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['AcP']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		AcP = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*AcP

		return rate

class vD_ACEex_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['D']
		self.reaction_substrate_names = ['ACEex']
		self.substrates = ['ACEex']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ACEex = substrates[0]


		D = parameters[0]



		rate=D*ACEex

		return rate

class vD_ICIT_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','ICIT','EIIAP','FBP','cAMP']
		self.substrates = ['ICIT']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		ICIT = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*ICIT

		return rate

class vD_aKG_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','aKG','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['aKG']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		aKG = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*aKG

		return rate

class vD_SUC_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','SUC','EIIAP','FBP','cAMP']
		self.substrates = ['SUC']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		SUC = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*SUC

		return rate

class vD_FUM_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FUM','FBP','cAMP']
		self.substrates = ['FUM']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FUM = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*FUM

		return rate

class vD_MAL_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','MAL','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['MAL']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		MAL = substrates[1]
		pH = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*MAL

		return rate

class vD_OAA_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','OAA','FBP','cAMP']
		self.substrates = ['OAA']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		OAA = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*OAA

		return rate

class vD_GOX_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','GOX','FBP','cAMP']
		self.substrates = ['GOX']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		GOX = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*GOX

		return rate

class vD_6PGL_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','sixPGL','FBP','cAMP']
		self.substrates = ['sixPGL']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		sixPGL = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*sixPGL

		return rate

class vD_6PG_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','sixPG','EIIAP','FBP','cAMP']
		self.substrates = ['sixPG']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		sixPG = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*sixPG

		return rate

class vD_KDPG_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','KDPG','EIIAP','FBP','cAMP']
		self.substrates = ['KDPG']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		KDPG = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*KDPG

		return rate

class vD_RU5P_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','RU5P','FBP','cAMP']
		self.substrates = ['RU5P']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		RU5P = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*RU5P

		return rate

class vD_R5P_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','R5P','EIIAP','FBP','cAMP']
		self.substrates = ['R5P']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		R5P = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*R5P

		return rate

class vD_X5P_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','X5P','FBP','cAMP']
		self.substrates = ['X5P']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		X5P = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*X5P

		return rate

class vD_S7P_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','S7P','FBP','cAMP']
		self.substrates = ['S7P']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		S7P = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*S7P

		return rate

class vD_E4P_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','E4P','FBP','cAMP']
		self.substrates = ['E4P']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		E4P = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*E4P

		return rate

class vD_cAMP_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['cAMP']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		FBP = substrates[4]
		cAMP = substrates[5]


		kATP = parameters[0]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=mu*cAMP

		return rate

class vD_Glk_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','Glk','FBP','cAMP']
		self.substrates = ['Glk']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		Glk = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*Glk

		return rate

class vD_Pfk_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['ATP','pH','PYR','Pfk','EIIAP','FBP','cAMP']
		self.substrates = ['Pfk']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		Pfk = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*Pfk

		return rate

class vD_Fbp_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['ATP','pH','Fbp','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['Fbp']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		Fbp = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*Fbp

		return rate

class vD_Fba_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','Fba','FBP','cAMP']
		self.substrates = ['Fba']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		Fba = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*Fba

		return rate

class vD_Gapdh_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','Gapdh','FBP','cAMP']
		self.substrates = ['GAPDH']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		Gapdh = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*Gapdh

		return rate

class vD_Pyk_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['ATP','pH','PYR','Pyk','EIIAP','FBP','cAMP']
		self.substrates = ['Pyk']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		Pyk = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*Pyk

		return rate

class vD_Pps_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['Pps','ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['Pps']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		Pps = substrates[0]
		ATP = substrates[1]
		pH = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*Pps

		return rate

class vD_Pdh_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['ATP','pH','PYR','Pdh','EIIAP','FBP','cAMP']
		self.substrates = ['PDH']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		Pdh = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*Pdh

		return rate

class vD_Acs_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['ATP','Acs','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['Acs']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		Acs = substrates[1]
		pH = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*Acs

		return rate

class vD_Cs_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','Cs','FBP','cAMP']
		self.substrates = ['CS']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		Cs = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*Cs

		return rate

class vD_Icdh_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['Icdh','ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['ICDH']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		Icdh = substrates[0]
		ATP = substrates[1]
		pH = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*Icdh

		return rate

class vD_IcdhP_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['IcdhP','ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['ICDHP']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		IcdhP = substrates[0]
		ATP = substrates[1]
		pH = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*IcdhP

		return rate

class vD_akgdh_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['ATP','pH','akgdh','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['aKGDH']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		akgdh = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*akgdh

		return rate

class vD_Sdh_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['ATP','pH','Sdh','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['SDH']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		Sdh = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*Sdh

		return rate

class vD_Fum_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['ATP','pH','Fum','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['Fum']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		Fum = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*Fum

		return rate

class vD_Mdh_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','Mdh','FBP','cAMP']
		self.substrates = ['MDH']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		Mdh = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*Mdh

		return rate

class vD_MaeB_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','MaeB','FBP','cAMP']
		self.substrates = ['MaeB']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		MaeB = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*MaeB

		return rate

class vD_Pck_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['ATP','pH','Pck','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['Pck']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		Pck = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*Pck

		return rate

class vD_Ppc_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['Ppc','ATP','pH','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['Ppc']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		Ppc = substrates[0]
		ATP = substrates[1]
		pH = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*Ppc

		return rate

class vD_Icl_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['ATP','pH','Icl','PYR','EIIAP','FBP','cAMP']
		self.substrates = ['Icl']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		Icl = substrates[2]
		PYR = substrates[3]
		EIIAP = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*Icl

		return rate

class vD_Ms_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','Ms','FBP','cAMP']
		self.substrates = ['MS']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		Ms = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*Ms

		return rate

class vD_AceK_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kATP','kdegr']
		self.reaction_substrate_names = ['ATP','pH','PYR','EIIAP','AceK','FBP','cAMP']
		self.substrates = ['AceK']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		ATP = substrates[0]
		pH = substrates[1]
		PYR = substrates[2]
		EIIAP = substrates[3]
		AceK = substrates[4]
		FBP = substrates[5]
		cAMP = substrates[6]


		kATP = parameters[0]
		kdegr = parameters[1]



		mu=kATP*ATP
		mu=kATP*ATP
		rate=(mu+kdegr)*AceK

		return rate

class vBM_G6P_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kBM_GLC_G6P']
		self.reaction_substrate_names = ['G6P']
		self.substrates = ['G6P']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		G6P = substrates[0]


		kBM_GLC_G6P = parameters[0]



		rate=kBM_GLC_G6P*G6P

		return rate

class vBM_F6P_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kBM_GLC_F6P']
		self.reaction_substrate_names = ['F6P']
		self.substrates = ['F6P']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		F6P = substrates[0]


		kBM_GLC_F6P = parameters[0]



		rate=kBM_GLC_F6P*F6P

		return rate

class vBM_GAP_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kBM_GLC_GAP']
		self.reaction_substrate_names = ['GAP']
		self.substrates = ['GAP']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		GAP = substrates[0]


		kBM_GLC_GAP = parameters[0]



		rate=kBM_GLC_GAP*GAP

		return rate

class vBM_PEP_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kBM_GLC_PEP']
		self.reaction_substrate_names = ['PEP']
		self.substrates = ['PEP']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		PEP = substrates[0]


		kBM_GLC_PEP = parameters[0]



		rate=kBM_GLC_PEP*PEP

		return rate

class vBM_PYR_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kBM_GLC_PYR']
		self.reaction_substrate_names = ['PYR']
		self.substrates = ['PYR']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		PYR = substrates[0]


		kBM_GLC_PYR = parameters[0]



		rate=kBM_GLC_PYR*PYR

		return rate

class vBM_AcCoA_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kBM_GLC_AcCoA']
		self.reaction_substrate_names = ['AcCoA']
		self.substrates = ['AcCoA']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		AcCoA = substrates[0]


		kBM_GLC_AcCoA = parameters[0]



		rate=kBM_GLC_AcCoA*AcCoA

		return rate

class vBM_aKG_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kBM_GLC_aKG']
		self.reaction_substrate_names = ['aKG']
		self.substrates = ['aKG']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		aKG = substrates[0]


		kBM_GLC_aKG = parameters[0]



		rate=kBM_GLC_aKG*aKG

		return rate

class vBM_SUC_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kBM_GLC_SUC']
		self.reaction_substrate_names = ['SUC']
		self.substrates = ['SUC']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		SUC = substrates[0]


		kBM_GLC_SUC = parameters[0]



		rate=kBM_GLC_SUC*SUC

		return rate

class vBM_FUM_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kBM_GLC_FUM']
		self.reaction_substrate_names = ['FUM']
		self.substrates = ['FUM']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		FUM = substrates[0]


		kBM_GLC_FUM = parameters[0]



		rate=kBM_GLC_FUM*FUM

		return rate

class vBM_OAA_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kBM_GLC_OAA']
		self.reaction_substrate_names = ['OAA']
		self.substrates = ['OAA']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		OAA = substrates[0]


		kBM_GLC_OAA = parameters[0]



		rate=kBM_GLC_OAA*OAA

		return rate

class vBM_R5P_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kBM_GLC_R5P']
		self.reaction_substrate_names = ['R5P']
		self.substrates = ['R5P']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		R5P = substrates[0]


		kBM_GLC_R5P = parameters[0]



		rate=kBM_GLC_R5P*R5P

		return rate

class vBM_E4P_Reaction(kinetics.Reaction):
	def __init__(self,param1='',param2='',species1='',species2='',substrates=[],products=[]):
	
		super().__init__()
		self.parameter_names=['kBM_GLC_E4P']
		self.reaction_substrate_names = ['E4P']
		self.substrates = ['E4P']
		self.products = []


	def calculate_rate(self, substrates, parameters):
		E4P = substrates[0]


		kBM_GLC_E4P = parameters[0]



		rate=kBM_GLC_E4P*E4P

		return rate

